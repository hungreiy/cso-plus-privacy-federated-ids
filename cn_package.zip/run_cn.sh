#!/usr/bin/env bash
# Cloud-native DP experiment: does the extended CSO+ ontology help the hybrid DP-FL detector on real cloud-native traffic?
# Needs on the volume: /workspace/cloud_native_v4.csv (the testbed dataset) and /workspace/cso_ext/cso_plus_node2vec.npz (extended embeddings).
#   cd /workspace && unzip -o -q cn_package.zip -d thesis_experiments 2>/dev/null; nohup bash thesis_experiments/run_cn.sh > /workspace/cn.log 2>&1 &
set -uo pipefail
W=/workspace; P=$W/thesis_experiments; S=$P/src; AUTO_STOP=${AUTO_STOP:-1}
export UV_CACHE_DIR=/root/.cache/uv PIP_CACHE_DIR=/root/.cache/pip XDG_CACHE_HOME=/root/.cache UV_LINK_MODE=copy
say(){ echo "==== [$(date '+%Y-%m-%d %H:%M:%S')] $*"; }
run(){ local out=$1; shift; if [ -f "$out" ]; then echo "skip $out"; else python "$@" || return 1; fi; }
say "step 1/4: environment"
if [ ! -x /root/venv311/bin/python ]; then pip install -q uv && uv venv --python 3.11 /root/venv311 || exit 1; fi
source /root/venv311/bin/activate; cd $P && uv pip install -q -r requirements.txt || { say "ERROR packages"; exit 1; }
cd $S
[ -f $W/cloud_native_v4.csv ] || { say "ERROR: /workspace/cloud_native_v4.csv not found"; exit 1; }
[ -f $W/cso_ext/cso_plus_node2vec.npz ] || { say "ERROR: /workspace/cso_ext/cso_plus_node2vec.npz not found"; exit 1; }
say "step 2/4: adapt the testbed dataset to CSV windows format"
mkdir -p /root/cn_csv
[ -f /root/cn_csv/testbed.csv ] || python adapt_testbed.py $W/cloud_native_v4.csv /root/cn_csv/testbed.csv
say "step 3/4: prepare windows (window 15, 10 tenants, IID) with the EXTENDED ontology embeddings"
[ -f /root/cn_prep/meta.json ] || python data.py --csv_dir /root/cn_csv --kg $W/cso_ext/cso_plus_node2vec.npz --out_dir /root/cn_prep --n_tenants 10 --partition iid --dataset cic2017 --benign_label benign --block 100 || { say "ERROR prep"; exit 1; }
# random-embedding control: same shape, shuffled/random vectors
[ -f /root/cn_prep_rand/meta.json ] || python - <<'PY'
import numpy as np, os, shutil
z=np.load('/workspace/cso_ext/cso_plus_node2vec.npz'); v=z['vectors']
rng=np.random.default_rng(0); rv=rng.normal(v.mean(0),v.std(0)+1e-9,size=v.shape).astype(np.float32)
os.makedirs('/root/cso_rand',exist_ok=True); np.savez('/root/cso_rand/kg.npz',ports=z['ports'],vectors=rv)
PY
[ -f /root/cn_prep_rand/meta.json ] || python data.py --csv_dir /root/cn_csv --kg /root/cso_rand/kg.npz --out_dir /root/cn_prep_rand --n_tenants 10 --partition iid --dataset cic2017 --benign_label benign --block 100 || true
say "step 4/4: train the hybrid DP-FL model (sigma 1.455, eps~8), 3 seeds, three input conditions"
FL="--dp on --sigma 1.455 --clients 10 --rounds 50 --local_epochs 5 --fraction 0.3 --gpus_per_client 1.0"
FAILED=""
for s in 0 1 2; do
  run results_cn/fl_dp_kg_seed$s.json    fl_flower.py $FL --prep /root/cn_prep      --out results_cn --seed $s --tag kg  || FAILED="$FAILED kg$s"
  run results_cn/fl_dp_rand_seed$s.json  fl_flower.py $FL --prep /root/cn_prep_rand --out results_cn --seed $s --tag rand || FAILED="$FAILED rand$s"
  run results_cn/fl_dp_nokg_seed$s.json  fl_flower.py $FL --prep /root/cn_prep      --out results_cn --seed $s --no_kg    || FAILED="$FAILED nokg$s"
  ( cd $S && python make_cn_table.py > $W/cn_results.md 2>/dev/null ) || true
  ( zip -q -r $W/cn_results.zip results_cn cn_results.md -x '*.pt' 2>/dev/null ) || true
done
[ -z "$FAILED" ] && say "ALL FINISHED" || say "FINISHED WITH FAILURES:$FAILED"
say "download /workspace/cn_results.zip and /workspace/cn.log"
if [ "$AUTO_STOP" = "1" ] && command -v runpodctl >/dev/null 2>&1 && [ -n "${RUNPOD_POD_ID:-}" ]; then say "stopping pod in 10 min"; sleep 600; runpodctl stop pod "$RUNPOD_POD_ID"; fi
