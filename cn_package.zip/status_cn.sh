#!/usr/bin/env bash
S=/workspace/thesis_experiments/src; date
pgrep -f run_cn.sh >/dev/null && echo "STATUS: RUNNING" || echo "STATUS: NOT RUNNING"
grep "^====" /workspace/cn.log 2>/dev/null | tail -5
echo "results: $(ls $S/results_cn/*_seed*.json 2>/dev/null | grep -v dp_log | wc -l)/9"
nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader 2>/dev/null | sed 's/^/GPU: /'
