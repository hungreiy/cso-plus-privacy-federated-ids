#!/usr/bin/env python3
# Convert the testbed dataset (25 cols, one flow per row) into the CSV format data.py expects:
# a 'Label' column, a 'Destination Port' column, and numeric flow features. Flows are kept in capture order
# (grouped by sample) so that data.py's 15-flow windows and block splits stay meaningful.
import sys, pandas as pd, numpy as np
src, dst = sys.argv[1], sys.argv[2]
df = pd.read_csv(src, low_memory=False)
df = df.sort_values('sample', kind='stable').reset_index(drop=True)      # keep each capture's flows together
feat = ['flow_duration','total_packets','total_bytes','pkt_len_min','pkt_len_max','pkt_len_mean','pkt_len_std',
        'bytes_per_s','pkts_per_s','iat_mean','iat_std','iat_min','iat_max','syn','fin','rst','psh','ack']
out = df[feat].apply(pd.to_numeric, errors='coerce').replace([np.inf,-np.inf],np.nan).fillna(0.0)
out.insert(0, 'Destination Port', pd.to_numeric(df['dst_port'].astype(str).str.replace('.0','',regex=False),errors='coerce').fillna(0).astype(int).clip(0,65535))
# collapse the three attack types to BENIGN vs attack-named labels (keep type for unseen-holdout flexibility)
out['Label'] = df['Label'].where(df['Label']=='benign', df['Label'].str.replace('attack-','',regex=False))
out.to_csv(dst, index=False)
print('wrote', dst, '|', len(out), 'flows |', out['Label'].value_counts().to_dict())
