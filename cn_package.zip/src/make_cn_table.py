import json, glob, numpy as np
def L(tag): return [json.load(open(f)) for f in sorted(glob.glob(f'results_cn/{tag}_seed*.json'))]
ms=lambda v: f'{np.mean(v):.4f} ± {np.std(v,ddof=1):.4f}' if len(v)>1 else (f'{v[0]:.4f}' if v else '-')
out=['\n### Cloud-native dataset under DP-FL (sigma 1.455, eps~8, 3 seeds)\n','| Input | n | F1 all | F1 clear | AUC | eps |','|---|---|---|---|---|---|']
for tag,name in (('fl_dp_nokg','No embeddings'),('fl_dp_rand','Random vectors'),('fl_dp_kg','Extended CSO+ embeddings')):
    J=L(tag)
    if J: out.append(f"| {name} | {len(J)} | {ms([j['f1'] for j in J])} | {ms([j['clean']['f1'] for j in J])} | {ms([j['auc'] for j in J])} | {ms([j['privacy']['eps_opacus'] for j in J],2)} |")
open('/dev/stdout','w').write('\n'.join(out)+'\n')
